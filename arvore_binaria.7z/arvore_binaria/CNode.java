public class CNode
{
    public int item;
    public CNode left, right;

    public CNode()
    {
        item = 0;
        left = right = null;
    }

    public CNode(int item)
    {
        this.item = item;
        left = right = null;
    }

    public CNode(int item, CNode left)
    {
        this.item = item;
        this.left = left;
        this.right = null;
    }

    public CNode(int item, CNode left, CNode right)
    {
        this.item = item;
        this.left = left;
        this.right = right;
    }

    public void SetLeft(CNode left)
    {
        this.left = left;
    }

    public void SetRight(CNode right)
    {
        this.right = right;
    }

    public void SetItem(int item)
    {
        this.item = item;
    }
}