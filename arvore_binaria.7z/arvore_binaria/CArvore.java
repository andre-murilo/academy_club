public class CArvore
{
    private CNode raiz;

    public CArvore()
    {
        raiz = new CNode();
    }

    public CArvore(int item)
    {
        raiz = new CNode(item);
    }

    public boolean vazia()
    {
        return (raiz.left == null && raiz.right == null);
    }

    public void inserir(CNode node)
    {   
        if(node.item < raiz.item)
        {
            // percorrer pela esquerda
            for(CNode n = raiz.left; n != null; n = n.left)
            {
                if(node.item < n.item)
                    insertLeft(n, node);
                else
                    insertRight(n, node);
            }
        }
        else
        {
            // percorrer pela direita
            for(CNode n = raiz.right; n != null; n = n.right)
            {
                if(node.item > n.item)
                    insertLeft(n, node);
                else
                    insertRight(n, node);
            }
        }
  
    }

    public void insertLeft(CNode node, CNode value)
    {
        node.left = value;
    }

    public void insertRight(CNode node, CNode value)
    {
        node.right = value;
    }


    public void printleft()
    {
        for(CNode n = raiz.left; n != null; n = n.left)
        {
            System.out.println(n.item);
        }
    }

    public void printRight()
    {
        // percorrer pela direita
        for(CNode n = raiz.right; n != null; n = n.right)
        {
            System.out.println(n.item);
        }
    }
}
