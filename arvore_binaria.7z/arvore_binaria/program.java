import java.util.Scanner;

public class program
{
    public static void main(String[] args) {

        CArvore arvore = new CArvore(10);

        arvore.inserir(new CNode(3));
        arvore.printleft();
        arvore.printRight();
    }
}
